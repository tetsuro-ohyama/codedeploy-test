#!/bin/bash
set -eu

# do something
sleep 180
#exit 1